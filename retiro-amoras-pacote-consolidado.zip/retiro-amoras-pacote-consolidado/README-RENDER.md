# Pacote consolidado para Render

Este pacote foi preparado para evitar o erro:

`failed to read dockerfile: open Dockerfile: no such file or directory`

## O que mudou
- `Dockerfile` agora está na raiz
- `render.yaml` incluído
- projeto completo dentro da pasta `app/`

## Como publicar
1. Suba este pacote descompactado para um repositório GitHub
2. No Render:
   - New
   - Web Service
   - Connect Repository
3. O Render encontrará o `Dockerfile` na raiz sem precisar de `Root Directory`

## Variáveis mínimas
Configure no Render:
- `SECRET_KEY`
- `DATABASE_URL`
- `FIRST_SUPERUSER_EMAIL`
- `FIRST_SUPERUSER_PASSWORD`

Opcionalmente mantenha:
- `PORT=10000`
- `APP_NAME=Retiro Amoras API`
- `API_V1_STR=/api/v1`
- `ALGORITHM=HS256`
- `ACCESS_TOKEN_EXPIRE_MINUTES=120`

## Rotas para testar após deploy
- `/`
- `/health`
- `/docs`
