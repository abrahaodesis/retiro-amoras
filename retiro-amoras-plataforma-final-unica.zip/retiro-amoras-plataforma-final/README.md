# Módulo de Billing — Retiro Amoras

Este pacote adiciona monetização SaaS ao sistema multi-tenant:

- planos
- assinaturas
- pagamentos
- limites de uso
- verificação de tenant ativo
- bloqueio por assinatura

## Objetivo
Permitir cobrança por cliente/igreja/evento e controlar acesso por plano.

## Entidades novas
- `plans`
- `subscriptions`
- `billing_payments`

## Regras iniciais
- tenant precisa ter assinatura ativa
- tenant pode ter limite de participantes
- tenant pode ter limite de reservas

## Próximo passo
Conectar gateway de pagamento real e automação de cobrança.


## Versão única com multi-tenant e billing

Esta entrega também incorpora na base principal:

- suporte multi-tenant
- tenants
- billing
- planos
- assinaturas
- pagamentos
- documentação de integração
- migrations adicionais

Arquivos de referência:
- `VERSAO_UNICA_FINAL.md`
- `backend/INTEGRACAO_MULTITENANT.md`
- `backend/INTEGRACAO_BILLING.md`

### Novas rotas esperadas
- `/api/v1/tenants`
- `/api/v1/billing/plans`
- `/api/v1/billing/subscriptions`
- `/api/v1/billing/payments`
