# Configuração do CI/CD com GitHub Actions

## Workflows incluídos

- `.github/workflows/ci.yml`
- `.github/workflows/deploy.yml`

## O que o CI faz

### Backend
- instala dependências Python
- faz um smoke test importando a aplicação FastAPI

### Frontend
- instala dependências Node
- executa build de produção

## O que o deploy faz

- copia o projeto para o servidor via SCP
- acessa o servidor via SSH
- entra na pasta de deploy
- sobe o ambiente com `docker compose up -d --build`

## Secrets necessários no GitHub

Em:
`Settings > Secrets and variables > Actions`

Crie estes secrets:

- `SSH_HOST` = IP ou domínio do servidor
- `SSH_USER` = usuário SSH
- `SSH_PRIVATE_KEY` = chave privada SSH
- `SSH_PORT` = porta SSH, normalmente `22`
- `DEPLOY_PATH` = caminho no servidor, por exemplo `/opt/retiro-amoras`

## Exemplo de DEPLOY_PATH

```bash
/opt/retiro-amoras
```

## Pré-requisitos no servidor

- Docker instalado
- Docker Compose disponível
- DNS já apontado
- portas 80 e 443 liberadas
- diretório de deploy com permissão para o usuário SSH

## Fluxo recomendado

1. Push na branch `main`
2. GitHub Actions executa CI
3. GitHub Actions executa deploy
4. Servidor atualiza containers

## Ajustes recomendados

- separar ambiente staging e produção
- usar branch protegida
- adicionar testes automatizados reais
- adicionar backup antes do deploy
- implementar estratégia de rollback
