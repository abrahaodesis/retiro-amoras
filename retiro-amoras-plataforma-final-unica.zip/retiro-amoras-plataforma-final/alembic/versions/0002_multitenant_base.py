"""multitenant base

Revision ID: 0002_multitenant_base
Revises: 0001_initial_schema
Create Date: 2026-04-16 00:00:00
"""

from alembic import op
import sqlalchemy as sa

revision = "0002_multitenant_base"
down_revision = "0001_initial_schema"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "tenants",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column("name", sa.String(length=180), nullable=False),
        sa.Column("slug", sa.String(length=120), nullable=False),
        sa.Column("domain", sa.String(length=180), nullable=True),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_tenants_slug", "tenants", ["slug"], unique=True)

    for table in ["participants", "reservations", "transactions", "meal_dispenses", "audit_logs"]:
        op.add_column(table, sa.Column("tenant_id", sa.String(length=64), nullable=True))

    op.create_foreign_key("fk_participants_tenant", "participants", "tenants", ["tenant_id"], ["id"])
    op.create_foreign_key("fk_reservations_tenant", "reservations", "tenants", ["tenant_id"], ["id"])
    op.create_foreign_key("fk_transactions_tenant", "transactions", "tenants", ["tenant_id"], ["id"])
    op.create_foreign_key("fk_meal_dispenses_tenant", "meal_dispenses", "tenants", ["tenant_id"], ["id"])
    op.create_foreign_key("fk_audit_logs_tenant", "audit_logs", "tenants", ["tenant_id"], ["id"])

    op.create_index("ix_participants_tenant_id", "participants", ["tenant_id"], unique=False)
    op.create_index("ix_reservations_tenant_id", "reservations", ["tenant_id"], unique=False)
    op.create_index("ix_transactions_tenant_id", "transactions", ["tenant_id"], unique=False)
    op.create_index("ix_meal_dispenses_tenant_id", "meal_dispenses", ["tenant_id"], unique=False)
    op.create_index("ix_audit_logs_tenant_id", "audit_logs", ["tenant_id"], unique=False)

    # Ajuste manual recomendado:
    # 1) criar tenant default
    # 2) preencher tenant_id dos dados existentes
    # 3) marcar tenant_id como NOT NULL


def downgrade() -> None:
    op.drop_index("ix_audit_logs_tenant_id", table_name="audit_logs")
    op.drop_index("ix_meal_dispenses_tenant_id", table_name="meal_dispenses")
    op.drop_index("ix_transactions_tenant_id", table_name="transactions")
    op.drop_index("ix_reservations_tenant_id", table_name="reservations")
    op.drop_index("ix_participants_tenant_id", table_name="participants")

    op.drop_constraint("fk_audit_logs_tenant", "audit_logs", type_="foreignkey")
    op.drop_constraint("fk_meal_dispenses_tenant", "meal_dispenses", type_="foreignkey")
    op.drop_constraint("fk_transactions_tenant", "transactions", type_="foreignkey")
    op.drop_constraint("fk_reservations_tenant", "reservations", type_="foreignkey")
    op.drop_constraint("fk_participants_tenant", "participants", type_="foreignkey")

    for table in ["audit_logs", "meal_dispenses", "transactions", "reservations", "participants"]:
        op.drop_column(table, "tenant_id")

    op.drop_index("ix_tenants_slug", table_name="tenants")
    op.drop_table("tenants")
