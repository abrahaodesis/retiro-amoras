"""billing module

Revision ID: 0003_billing_module
Revises: 0002_multitenant_base
Create Date: 2026-04-16 00:10:00
"""

from alembic import op
import sqlalchemy as sa

revision = "0003_billing_module"
down_revision = "0002_multitenant_base"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "plans",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column("name", sa.String(length=120), nullable=False),
        sa.Column("code", sa.String(length=60), nullable=False),
        sa.Column("monthly_price_brl", sa.Float(), nullable=False),
        sa.Column("max_participants", sa.Integer(), nullable=False),
        sa.Column("max_reservations", sa.Integer(), nullable=False),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.true()),
    )
    op.create_index("ix_plans_code", "plans", ["code"], unique=True)

    op.create_table(
        "subscriptions",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column("tenant_id", sa.String(length=64), sa.ForeignKey("tenants.id"), nullable=False),
        sa.Column("plan_id", sa.String(length=64), sa.ForeignKey("plans.id"), nullable=False),
        sa.Column("status", sa.String(length=30), nullable=False),
        sa.Column("starts_at", sa.Date(), nullable=False),
        sa.Column("expires_at", sa.Date(), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_subscriptions_tenant_id", "subscriptions", ["tenant_id"], unique=False)
    op.create_index("ix_subscriptions_plan_id", "subscriptions", ["plan_id"], unique=False)

    op.create_table(
        "billing_payments",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column("tenant_id", sa.String(length=64), sa.ForeignKey("tenants.id"), nullable=False),
        sa.Column("subscription_id", sa.String(length=64), sa.ForeignKey("subscriptions.id"), nullable=False),
        sa.Column("amount_brl", sa.Float(), nullable=False),
        sa.Column("status", sa.String(length=30), nullable=False),
        sa.Column("payment_method", sa.String(length=40), nullable=False),
        sa.Column("paid_at", sa.Date(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_billing_payments_tenant_id", "billing_payments", ["tenant_id"], unique=False)
    op.create_index("ix_billing_payments_subscription_id", "billing_payments", ["subscription_id"], unique=False)


def downgrade() -> None:
    op.drop_index("ix_billing_payments_subscription_id", table_name="billing_payments")
    op.drop_index("ix_billing_payments_tenant_id", table_name="billing_payments")
    op.drop_table("billing_payments")
    op.drop_index("ix_subscriptions_plan_id", table_name="subscriptions")
    op.drop_index("ix_subscriptions_tenant_id", table_name="subscriptions")
    op.drop_table("subscriptions")
    op.drop_index("ix_plans_code", table_name="plans")
    op.drop_table("plans")
