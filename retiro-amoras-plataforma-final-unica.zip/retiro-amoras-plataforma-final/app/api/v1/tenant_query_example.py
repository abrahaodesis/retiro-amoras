# Exemplo de endpoint tenant-safe

from fastapi import Depends
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.api.deps import get_db
from app.api.deps_multitenant_patch import get_current_tenant
from app.models.participant import Participant


def list_participants_tenant_safe(
    db: Session = Depends(get_db),
    current_tenant = Depends(get_current_tenant),
):
    return db.scalars(
        select(Participant).where(Participant.tenant_id == current_tenant.id)
    ).all()
