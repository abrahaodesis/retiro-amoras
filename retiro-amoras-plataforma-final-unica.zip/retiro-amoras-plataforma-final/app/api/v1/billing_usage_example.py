# Exemplo de uso antes de criar participante

from fastapi import Depends
from sqlalchemy.orm import Session
from app.api.deps import get_db
from app.api.deps_multitenant_patch import get_current_tenant
from app.services.billing_service import ensure_plan_limit_for_participants


def guard_before_create_participant(
    db: Session = Depends(get_db),
    current_tenant = Depends(get_current_tenant),
):
    ensure_plan_limit_for_participants(db, current_tenant.id)
