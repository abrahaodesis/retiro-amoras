from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.api.deps import get_db, require_permission
from app.models.tenant import Tenant
from app.schemas.tenant import TenantCreate

router = APIRouter()


@router.get("/")
def read_tenants(
    db: Session = Depends(get_db),
    current_user = Depends(require_permission("admin:tenants")),
):
    items = db.scalars(select(Tenant).order_by(Tenant.created_at.desc())).all()
    return items


@router.post("/")
def create_tenant(
    payload: TenantCreate,
    db: Session = Depends(get_db),
    current_user = Depends(require_permission("admin:tenants")),
):
    existing = db.scalar(select(Tenant).where(Tenant.slug == payload.slug))
    if existing:
        raise HTTPException(status_code=409, detail="Slug já cadastrado")

    tenant = Tenant(name=payload.name, slug=payload.slug, domain=payload.domain, is_active=True)
    db.add(tenant)
    db.commit()
    db.refresh(tenant)
    return tenant
