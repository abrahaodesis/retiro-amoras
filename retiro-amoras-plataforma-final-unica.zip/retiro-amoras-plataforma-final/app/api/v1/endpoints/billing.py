from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import get_db, require_permission
from app.models.billing import Plan, Subscription, BillingPayment
from app.schemas.billing import PlanCreate, SubscriptionCreate, PaymentCreate

router = APIRouter()


@router.get("/plans")
def read_plans(
    db: Session = Depends(get_db),
    current_user = Depends(require_permission("admin:billing")),
):
    return db.scalars(select(Plan).order_by(Plan.name)).all()


@router.post("/plans")
def create_plan(
    payload: PlanCreate,
    db: Session = Depends(get_db),
    current_user = Depends(require_permission("admin:billing")),
):
    existing = db.scalar(select(Plan).where(Plan.code == payload.code))
    if existing:
        raise HTTPException(status_code=409, detail="Plano já existe")
    plan = Plan(**payload.model_dump(), is_active=True)
    db.add(plan)
    db.commit()
    db.refresh(plan)
    return plan


@router.get("/subscriptions")
def read_subscriptions(
    db: Session = Depends(get_db),
    current_user = Depends(require_permission("admin:billing")),
):
    return db.scalars(select(Subscription).order_by(Subscription.created_at.desc())).all()


@router.post("/subscriptions")
def create_subscription(
    payload: SubscriptionCreate,
    db: Session = Depends(get_db),
    current_user = Depends(require_permission("admin:billing")),
):
    subscription = Subscription(**payload.model_dump())
    db.add(subscription)
    db.commit()
    db.refresh(subscription)
    return subscription


@router.get("/payments")
def read_payments(
    db: Session = Depends(get_db),
    current_user = Depends(require_permission("admin:billing")),
):
    return db.scalars(select(BillingPayment).order_by(BillingPayment.created_at.desc())).all()


@router.post("/payments")
def create_payment(
    payload: PaymentCreate,
    db: Session = Depends(get_db),
    current_user = Depends(require_permission("admin:billing")),
):
    payment = BillingPayment(**payload.model_dump())
    db.add(payment)
    db.commit()
    db.refresh(payment)
    return payment
