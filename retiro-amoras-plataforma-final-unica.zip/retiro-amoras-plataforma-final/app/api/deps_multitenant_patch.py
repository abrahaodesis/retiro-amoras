from fastapi import Depends, Header, HTTPException, status
from sqlalchemy.orm import Session
from app.api.deps import get_current_user, get_db
from app.core.tenant_context import get_current_tenant_id
from app.models.tenant import Tenant


def get_current_tenant(
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-ID"),
    current_user = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    tenant_id = x_tenant_id or getattr(current_user, "tenant_id", None) or get_current_tenant_id()
    if not tenant_id:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Tenant não informado")

    tenant = db.get(Tenant, tenant_id)
    if not tenant or not tenant.is_active:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Tenant inválido ou inativo")
    return tenant
