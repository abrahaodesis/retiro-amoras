from datetime import datetime
from pydantic import BaseModel


class TenantCreate(BaseModel):
    name: str
    slug: str
    domain: str | None = None


class TenantOut(BaseModel):
    id: str
    name: str
    slug: str
    domain: str | None = None
    is_active: bool
    created_at: datetime
