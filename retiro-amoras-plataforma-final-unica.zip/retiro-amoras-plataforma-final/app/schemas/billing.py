from datetime import date, datetime
from pydantic import BaseModel, Field


class PlanCreate(BaseModel):
    name: str
    code: str
    monthly_price_brl: float = Field(..., ge=0)
    max_participants: int = Field(..., ge=0)
    max_reservations: int = Field(..., ge=0)


class SubscriptionCreate(BaseModel):
    tenant_id: str
    plan_id: str
    starts_at: date
    expires_at: date
    status: str = "active"


class PaymentCreate(BaseModel):
    tenant_id: str
    subscription_id: str
    amount_brl: float = Field(..., ge=0)
    payment_method: str = "manual"
    status: str = "paid"
    paid_at: date | None = None
