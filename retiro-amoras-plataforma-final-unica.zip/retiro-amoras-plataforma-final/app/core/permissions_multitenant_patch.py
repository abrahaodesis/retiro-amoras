# mescle com seu arquivo atual de permissions

ROLE_PERMISSIONS_PATCH = {
    "admin": {"*", "admin:tenants"},
    "financeiro": {"finance:read", "finance:write", "participants:read", "participants:write", "reservations:read", "dashboard:read"},
    "hospedagem": {"units:read", "reservations:read", "reservations:move", "participants:read", "dashboard:read"},
    "alimentacao": {"meals:read", "meals:write", "participants:read", "dashboard:read"},
    "participante": {"self:read"},
}
