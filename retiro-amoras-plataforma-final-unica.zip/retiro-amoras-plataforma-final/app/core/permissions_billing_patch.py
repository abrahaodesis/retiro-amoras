# mescle com permissions.py

ROLE_PERMISSIONS_BILLING_PATCH = {
    "admin": {"*", "admin:billing", "admin:tenants"},
    "financeiro": {"finance:read", "finance:write", "participants:read", "participants:write", "reservations:read", "dashboard:read"},
}
