from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from app.core.tenant_context import set_current_tenant_id


class TenantResolverMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        tenant_id = request.headers.get("X-Tenant-ID")
        if tenant_id:
            set_current_tenant_id(tenant_id)
        response = await call_next(request)
        return response
