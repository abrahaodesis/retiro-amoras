from datetime import date
from sqlalchemy import select, func
from sqlalchemy.orm import Session
from fastapi import HTTPException, status

from app.models.billing import Plan, Subscription
from app.models.participant import Participant
from app.models.reservation import Reservation


def get_active_subscription(db: Session, tenant_id: str):
    today = date.today()
    return db.scalar(
        select(Subscription).where(
            Subscription.tenant_id == tenant_id,
            Subscription.status == "active",
            Subscription.starts_at <= today,
            Subscription.expires_at >= today,
        )
    )


def ensure_tenant_subscription_active(db: Session, tenant_id: str):
    subscription = get_active_subscription(db, tenant_id)
    if not subscription:
        raise HTTPException(
            status_code=status.HTTP_402_PAYMENT_REQUIRED,
            detail="Tenant sem assinatura ativa"
        )
    return subscription


def ensure_plan_limit_for_participants(db: Session, tenant_id: str):
    subscription = ensure_tenant_subscription_active(db, tenant_id)
    plan = db.get(Plan, subscription.plan_id)
    current = db.scalar(select(func.count(Participant.id)).where(Participant.tenant_id == tenant_id)) or 0
    if plan.max_participants > 0 and current >= plan.max_participants:
        raise HTTPException(status_code=403, detail="Limite de participantes do plano atingido")
    return plan


def ensure_plan_limit_for_reservations(db: Session, tenant_id: str):
    subscription = ensure_tenant_subscription_active(db, tenant_id)
    plan = db.get(Plan, subscription.plan_id)
    current = db.scalar(select(func.count(Reservation.id)).where(Reservation.tenant_id == tenant_id)) or 0
    if plan.max_reservations > 0 and current >= plan.max_reservations:
        raise HTTPException(status_code=403, detail="Limite de reservas do plano atingido")
    return plan
