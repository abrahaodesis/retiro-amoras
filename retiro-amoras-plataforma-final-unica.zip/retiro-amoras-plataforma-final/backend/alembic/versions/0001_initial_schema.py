"""initial schema

Revision ID: 0001_initial_schema
Revises: None
Create Date: 2026-04-15 00:00:00
"""

from alembic import op
import sqlalchemy as sa


revision = "0001_initial_schema"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "users",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column("email", sa.String(length=180), nullable=False),
        sa.Column("hashed_password", sa.String(length=255), nullable=False),
        sa.Column("full_name", sa.String(length=180), nullable=False),
        sa.Column("role", sa.String(length=40), nullable=False),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.true()),
    )
    op.create_index("ix_users_email", "users", ["email"], unique=True)

    op.create_table(
        "accommodation_types",
        sa.Column("key", sa.String(length=50), primary_key=True),
        sa.Column("name", sa.String(length=120), nullable=False),
        sa.Column("quantity", sa.Integer(), nullable=False),
        sa.Column("price", sa.Float(), nullable=False),
        sa.Column("capacity", sa.Integer(), nullable=False),
        sa.Column("unit_type", sa.String(length=20), nullable=False),
        sa.Column("gender", sa.String(length=1), nullable=True),
    )

    op.create_table(
        "units",
        sa.Column("id", sa.String(length=80), primary_key=True),
        sa.Column("type_key", sa.String(length=50), sa.ForeignKey("accommodation_types.key"), nullable=False),
        sa.Column("label", sa.String(length=140), nullable=False),
        sa.Column("capacity", sa.Integer(), nullable=False),
    )
    op.create_index("ix_units_type_key", "units", ["type_key"], unique=False)

    op.create_table(
        "participants",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column("full_name", sa.String(length=180), nullable=False),
        sa.Column("birth_date", sa.Date(), nullable=False),
        sa.Column("age", sa.Integer(), nullable=False),
        sa.Column("cpf", sa.String(length=20), nullable=False),
        sa.Column("phone", sa.String(length=25), nullable=False),
        sa.Column("gender", sa.String(length=1), nullable=False),
        sa.Column("restrictions", sa.Text(), nullable=False, server_default=""),
        sa.Column("pcd", sa.Text(), nullable=False, server_default=""),
        sa.Column("notes", sa.Text(), nullable=False, server_default=""),
        sa.Column("companion_preference", sa.Text(), nullable=False, server_default=""),
        sa.Column("accommodation_type_key", sa.String(length=50), sa.ForeignKey("accommodation_types.key"), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_participants_cpf", "participants", ["cpf"], unique=True)

    op.create_table(
        "reservations",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column("participant_id", sa.String(length=64), sa.ForeignKey("participants.id"), nullable=False),
        sa.Column("accommodation_type_key", sa.String(length=50), sa.ForeignKey("accommodation_types.key"), nullable=False),
        sa.Column("unit_id", sa.String(length=80), sa.ForeignKey("units.id"), nullable=True),
        sa.Column("total_amount", sa.Float(), nullable=False),
        sa.Column("installment_count", sa.Integer(), nullable=False),
        sa.Column("payment_method", sa.String(length=40), nullable=False),
        sa.Column("payment_date", sa.Date(), nullable=False),
        sa.Column("amount_paid", sa.Float(), nullable=False),
        sa.Column("status", sa.String(length=30), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_reservations_participant_id", "reservations", ["participant_id"], unique=True)
    op.create_index("ix_reservations_accommodation_type_key", "reservations", ["accommodation_type_key"], unique=False)
    op.create_index("ix_reservations_unit_id", "reservations", ["unit_id"], unique=False)

    op.create_table(
        "transactions",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column("reservation_id", sa.String(length=64), sa.ForeignKey("reservations.id"), nullable=False),
        sa.Column("participant_id", sa.String(length=64), sa.ForeignKey("participants.id"), nullable=False),
        sa.Column("participant_name", sa.String(length=180), nullable=False),
        sa.Column("amount", sa.Float(), nullable=False),
        sa.Column("method", sa.String(length=40), nullable=False),
        sa.Column("paid_at", sa.Date(), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_transactions_reservation_id", "transactions", ["reservation_id"], unique=False)
    op.create_index("ix_transactions_participant_id", "transactions", ["participant_id"], unique=False)

    op.create_table(
        "meal_dispenses",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column("participant_id", sa.String(length=64), sa.ForeignKey("participants.id"), nullable=False),
        sa.Column("day", sa.Date(), nullable=False),
        sa.Column("meal", sa.String(length=40), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_meal_dispenses_participant_id", "meal_dispenses", ["participant_id"], unique=False)

    op.create_table(
        "audit_logs",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column("action", sa.String(length=80), nullable=False),
        sa.Column("actor", sa.String(length=120), nullable=False),
        sa.Column("payload", sa.Text(), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )


def downgrade() -> None:
    op.drop_table("audit_logs")
    op.drop_index("ix_meal_dispenses_participant_id", table_name="meal_dispenses")
    op.drop_table("meal_dispenses")
    op.drop_index("ix_transactions_participant_id", table_name="transactions")
    op.drop_index("ix_transactions_reservation_id", table_name="transactions")
    op.drop_table("transactions")
    op.drop_index("ix_reservations_unit_id", table_name="reservations")
    op.drop_index("ix_reservations_accommodation_type_key", table_name="reservations")
    op.drop_index("ix_reservations_participant_id", table_name="reservations")
    op.drop_table("reservations")
    op.drop_index("ix_participants_cpf", table_name="participants")
    op.drop_table("participants")
    op.drop_index("ix_units_type_key", table_name="units")
    op.drop_table("units")
    op.drop_table("accommodation_types")
    op.drop_index("ix_users_email", table_name="users")
    op.drop_table("users")
