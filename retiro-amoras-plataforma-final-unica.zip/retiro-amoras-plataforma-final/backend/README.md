# Retiro Amoras Backend

## Como usar

1. Crie o banco PostgreSQL `retiro_amoras`
2. Copie `.env.example` para `.env`
3. Instale dependências:

```bash
pip install -r requirements.txt
```

4. Rode as migrations:

```bash
alembic upgrade head
```

5. Suba a API:

```bash
uvicorn app.main:app --reload
```

## Login inicial

- Email: admin@amoras.local
- Senha: Admin@123

## Swagger

- http://127.0.0.1:8000/docs
