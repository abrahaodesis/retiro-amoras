from sqlalchemy import func, select
from sqlalchemy.orm import Session
from app.models.reservation import Reservation
from app.models.transaction import Transaction


def summary(db: Session):
    total_contracted = db.scalar(
        select(func.coalesce(func.sum(Reservation.total_amount), 0)).where(Reservation.status != "cancelada")
    ) or 0
    total_received = db.scalar(select(func.coalesce(func.sum(Transaction.amount), 0))) or 0
    pending_count = db.scalar(select(func.count(Reservation.id)).where(Reservation.status == "pendente")) or 0
    return {
        "total_contracted": float(total_contracted),
        "total_received": float(total_received),
        "total_pending": float(total_contracted - total_received),
        "pending_count": int(pending_count),
    }
