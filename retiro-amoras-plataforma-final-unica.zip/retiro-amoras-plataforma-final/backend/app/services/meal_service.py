from datetime import date
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.models.meal import MealDispense
from app.models.participant import Participant

EVENT_DAYS = {date(2027, 2, 5), date(2027, 2, 6), date(2027, 2, 7), date(2027, 2, 8), date(2027, 2, 9), date(2027, 2, 10)}
MEAL_TYPES = ["Café da manhã", "Almoço", "Jantar", "Lanche"]


def projection(db: Session):
    participant_ids = db.scalars(select(Participant.id)).all()
    dispenses = db.scalars(select(MealDispense)).all()
    result = []
    for day in sorted(EVENT_DAYS):
        per_meal = {}
        for meal in MEAL_TYPES:
            dispensed_ids = {d.participant_id for d in dispenses if d.day == day and d.meal == meal}
            per_meal[meal] = len([p for p in participant_ids if p not in dispensed_ids])
        result.append({"day": day, "per_meal": per_meal})
    return result
