from sqlalchemy import func, select
from sqlalchemy.orm import Session
from app.models.participant import Participant
from app.models.reservation import Reservation
from app.services.finance_service import summary as finance_summary
from app.services.meal_service import projection as meal_projection
from app.services.reservation_service import occupancy_summary


def build_dashboard(db: Session):
    total_participants = db.scalar(select(func.count(Participant.id))) or 0
    paid = db.scalar(select(func.count(Reservation.id)).where(Reservation.status == "quitada")) or 0
    pending = db.scalar(select(func.count(Reservation.id)).where(Reservation.status == "pendente")) or 0
    waitlist = db.scalar(select(func.count(Reservation.id)).where(Reservation.status == "lista_espera")) or 0
    return {
        "kpis": {
            "total_participants": int(total_participants),
            "paid": int(paid),
            "pending": int(pending),
            "waitlist": int(waitlist),
        },
        "occupancy": occupancy_summary(db),
        "finance": finance_summary(db),
        "meals": meal_projection(db),
    }
