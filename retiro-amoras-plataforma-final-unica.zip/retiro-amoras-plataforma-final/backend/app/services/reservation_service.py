from datetime import date
from sqlalchemy import func, select
from sqlalchemy.orm import Session
from app.crud.audit import add_log
from app.models.accommodation import AccommodationType, Unit
from app.models.participant import Participant
from app.models.reservation import Reservation
from app.models.transaction import Transaction


def calc_age(birth_date: date) -> int:
    today = date.today()
    age = today.year - birth_date.year
    if (today.month, today.day) < (birth_date.month, birth_date.day):
        age -= 1
    return age


def get_accommodation_or_404(db: Session, type_key: str):
    acc = db.get(AccommodationType, type_key)
    if not acc:
        raise ValueError("Acomodação não encontrada")
    return acc


def remaining_for_type(db: Session, type_key: str) -> int:
    acc = get_accommodation_or_404(db, type_key)
    if acc.unit_type == "bed":
        used = db.scalar(
            select(func.count(Reservation.id)).where(
                Reservation.accommodation_type_key == type_key,
                Reservation.status != "cancelada",
            )
        ) or 0
        return max(acc.quantity - used, 0)

    used_units = db.scalar(
        select(func.count(Unit.id)).select_from(Unit).join(Reservation, Reservation.unit_id == Unit.id).where(
            Unit.type_key == type_key,
            Reservation.status != "cancelada",
        ).distinct()
    ) or 0
    return max(acc.quantity - used_units, 0)


def occupancy_summary(db: Session):
    accommodations = db.scalars(select(AccommodationType).order_by(AccommodationType.name)).all()
    out = []
    for acc in accommodations:
        remaining = remaining_for_type(db, acc.key)
        out.append({
            "key": acc.key,
            "name": acc.name,
            "quantity": acc.quantity,
            "price": acc.price,
            "used": acc.quantity - remaining,
            "remaining": remaining,
        })
    return out


def find_available_unit(db: Session, type_key: str):
    units = db.scalars(select(Unit).where(Unit.type_key == type_key).order_by(Unit.label)).all()
    for unit in units:
        active_count = db.scalar(
            select(func.count(Reservation.id)).where(
                Reservation.unit_id == unit.id,
                Reservation.status != "cancelada",
            )
        ) or 0
        if active_count < unit.capacity:
            return unit
    return None


def create_participant_with_reservation(db: Session, payload):
    acc = get_accommodation_or_404(db, payload.accommodation_type)
    if acc.gender and acc.gender != payload.gender:
        raise ValueError("Alojamento incompatível com o sexo informado")
    if remaining_for_type(db, payload.accommodation_type) <= 0:
        raise ValueError("Acomodação esgotada")

    participant = Participant(
        full_name=payload.full_name,
        birth_date=payload.birth_date,
        age=calc_age(payload.birth_date),
        cpf=payload.cpf,
        phone=payload.phone,
        gender=payload.gender,
        restrictions=payload.restrictions,
        pcd=payload.pcd,
        notes=payload.notes,
        companion_preference=payload.companion_preference,
        accommodation_type_key=acc.key,
    )
    db.add(participant)
    db.flush()

    unit = None
    status = "quitada" if payload.paid_now else "pendente"
    if acc.unit_type == "apartment":
        unit = find_available_unit(db, acc.key)
        if not unit:
            status = "lista_espera"

    reservation = Reservation(
        participant_id=participant.id,
        accommodation_type_key=acc.key,
        unit_id=unit.id if unit else None,
        total_amount=payload.payment_amount,
        installment_count=payload.installment_count,
        payment_method=payload.payment_method,
        payment_date=payload.payment_date,
        amount_paid=payload.payment_amount if payload.paid_now else 0,
        status=status,
    )
    db.add(reservation)
    db.flush()

    transaction = None
    if payload.paid_now:
        transaction = Transaction(
            reservation_id=reservation.id,
            participant_id=participant.id,
            participant_name=participant.full_name,
            amount=payload.payment_amount,
            method=payload.payment_method,
            paid_at=payload.payment_date,
        )
        db.add(transaction)

    add_log(db, "CREATE_PARTICIPANT", f"participant_id={participant.id};reservation_id={reservation.id};status={status}")
    db.commit()
    db.refresh(participant)
    db.refresh(reservation)
    return participant, reservation, transaction, acc, unit
