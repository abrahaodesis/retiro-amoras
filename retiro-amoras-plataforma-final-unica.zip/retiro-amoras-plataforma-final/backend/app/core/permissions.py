ROLE_PERMISSIONS = {
    "admin": {"*", "admin:tenants", "admin:billing"},
    "financeiro": {"finance:read", "finance:write", "participants:read", "participants:write", "reservations:read", "dashboard:read"},
    "hospedagem": {"units:read", "reservations:read", "reservations:move", "participants:read", "dashboard:read"},
    "alimentacao": {"meals:read", "meals:write", "participants:read", "dashboard:read"},
    "participante": {"self:read"},
}


def has_permission(role: str, permission: str) -> bool:
    permissions = ROLE_PERMISSIONS.get(role, set())
    return "*" in permissions or permission in permissions
