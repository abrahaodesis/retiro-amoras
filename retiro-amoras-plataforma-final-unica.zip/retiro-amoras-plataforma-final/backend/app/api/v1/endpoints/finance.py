from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.api.deps import get_db, require_permission
from app.crud.transaction import list_all
from app.services.finance_service import summary

router = APIRouter()


@router.get("/transactions")
def read_transactions(db: Session = Depends(get_db), current_user=Depends(require_permission("finance:read"))):
    transactions = list_all(db)
    return [
        {
            "id": t.id,
            "reservation_id": t.reservation_id,
            "participant_id": t.participant_id,
            "participant_name": t.participant_name,
            "amount": t.amount,
            "method": t.method,
            "paid_at": t.paid_at,
        }
        for t in transactions
    ]


@router.get("/summary")
def read_finance_summary(db: Session = Depends(get_db), current_user=Depends(require_permission("finance:read"))):
    return summary(db)
