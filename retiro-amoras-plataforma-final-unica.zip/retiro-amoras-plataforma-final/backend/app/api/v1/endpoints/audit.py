from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.api.deps import get_db, require_permission
from app.crud.audit import list_all

router = APIRouter()


@router.get("/")
def read_audit(db: Session = Depends(get_db), current_user=Depends(require_permission("audit:read"))):
    logs = list_all(db)
    return [{"id": log.id, "at": log.created_at, "action": log.action, "actor": log.actor, "payload": log.payload} for log in logs]
