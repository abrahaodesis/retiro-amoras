from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.api.deps import get_db, require_permission
from app.services.dashboard_service import build_dashboard

router = APIRouter()


@router.get("/")
def read_dashboard(db: Session = Depends(get_db), current_user=Depends(require_permission("dashboard:read"))):
    return build_dashboard(db)
