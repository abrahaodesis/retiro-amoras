from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.api.deps import get_db, require_permission
from app.crud.audit import add_log
from app.models.meal import MealDispense
from app.models.participant import Participant
from app.schemas.meal import MealDispenseCreate
from app.services.meal_service import EVENT_DAYS, projection

router = APIRouter()


@router.get("/dispenses")
def read_meal_dispenses(db: Session = Depends(get_db), current_user=Depends(require_permission("meals:read"))):
    items = db.scalars(select(MealDispense).order_by(MealDispense.created_at.desc())).all()
    return [{"id": x.id, "participant_id": x.participant_id, "day": x.day, "meal": x.meal} for x in items]


@router.post("/dispense")
def toggle_meal_dispense(
    payload: MealDispenseCreate,
    db: Session = Depends(get_db),
    current_user=Depends(require_permission("meals:write")),
):
    if payload.day not in EVENT_DAYS:
        raise HTTPException(status_code=400, detail="Dia fora do período do evento")
    participant = db.get(Participant, payload.participant_id)
    if not participant:
        raise HTTPException(status_code=404, detail="Participante não encontrado")
    existing = db.scalar(
        select(MealDispense).where(
            MealDispense.participant_id == payload.participant_id,
            MealDispense.day == payload.day,
            MealDispense.meal == payload.meal,
        )
    )
    if existing:
        db.delete(existing)
        add_log(db, "REMOVE_MEAL_DISPENSE", f"participant_id={payload.participant_id};day={payload.day};meal={payload.meal}", actor=current_user.email)
        db.commit()
        return {"action": "removed"}
    item = MealDispense(participant_id=payload.participant_id, day=payload.day, meal=payload.meal)
    db.add(item)
    add_log(db, "ADD_MEAL_DISPENSE", f"participant_id={payload.participant_id};day={payload.day};meal={payload.meal}", actor=current_user.email)
    db.commit()
    return {"action": "added", "id": item.id}


@router.get("/projection")
def read_meal_projection(db: Session = Depends(get_db), current_user=Depends(require_permission("meals:read"))):
    return projection(db)
