from fastapi import APIRouter, Depends, Query
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.api.deps import get_db, require_permission
from app.models.accommodation import Unit
from app.models.reservation import Reservation

router = APIRouter()


@router.get("/")
def read_units(
    type_key: str | None = Query(default=None),
    db: Session = Depends(get_db),
    current_user=Depends(require_permission("units:read")),
):
    stmt = select(Unit)
    if type_key:
        stmt = stmt.where(Unit.type_key == type_key)
    units = db.scalars(stmt.order_by(Unit.label)).all()
    rows = []
    for unit in units:
        occupants = db.scalars(
            select(Reservation.participant_id).where(
                Reservation.unit_id == unit.id,
                Reservation.status != "cancelada",
            )
        ).all()
        rows.append({
            "id": unit.id,
            "type_key": unit.type_key,
            "label": unit.label,
            "capacity": unit.capacity,
            "occupants": occupants,
        })
    return rows
