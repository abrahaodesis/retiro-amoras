from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, select
from sqlalchemy.orm import Session
from app.api.deps import get_db, require_permission
from app.crud.audit import add_log
from app.crud.reservation import get_by_id, list_all
from app.models.accommodation import AccommodationType, Unit
from app.models.participant import Participant
from app.models.reservation import Reservation
from app.models.transaction import Transaction
from app.schemas.reservation import MoveReservationInput

router = APIRouter()


@router.get("/")
def read_reservations(db: Session = Depends(get_db), current_user=Depends(require_permission("reservations:read"))):
    reservations = list_all(db)
    rows = []
    for r in reservations:
        p = db.get(Participant, r.participant_id)
        acc = db.get(AccommodationType, r.accommodation_type_key)
        unit = db.get(Unit, r.unit_id) if r.unit_id else None
        rows.append({
            "id": r.id,
            "participant_id": p.id if p else None,
            "participant_name": p.full_name if p else None,
            "accommodation_type": acc.key,
            "accommodation_type_name": acc.name,
            "unit_id": r.unit_id,
            "unit_label": unit.label if unit else (acc.name if acc.unit_type == "bed" else None),
            "total_amount": r.total_amount,
            "installment_count": r.installment_count,
            "payment_method": r.payment_method,
            "payment_date": r.payment_date,
            "amount_paid": r.amount_paid,
            "status": r.status,
            "created_at": r.created_at,
        })
    return rows


@router.patch("/{reservation_id}/cancel")
def cancel_reservation(reservation_id: str, db: Session = Depends(get_db), current_user=Depends(require_permission("reservations:write"))):
    reservation = get_by_id(db, reservation_id)
    if not reservation:
        raise HTTPException(status_code=404, detail="Reserva não encontrada")
    reservation.status = "cancelada"
    add_log(db, "CANCEL_RESERVATION", f"reservation_id={reservation_id}", actor=current_user.email)
    db.commit()
    return {"status": reservation.status}


@router.patch("/{reservation_id}/pay")
def pay_reservation(reservation_id: str, db: Session = Depends(get_db), current_user=Depends(require_permission("finance:write"))):
    reservation = get_by_id(db, reservation_id)
    if not reservation:
        raise HTTPException(status_code=404, detail="Reserva não encontrada")
    if reservation.status == "cancelada":
        raise HTTPException(status_code=400, detail="Reserva cancelada não pode ser quitada")
    if reservation.status == "quitada":
        return {"status": reservation.status}
    participant = db.get(Participant, reservation.participant_id)
    reservation.status = "quitada"
    reservation.amount_paid = reservation.total_amount
    transaction = Transaction(
        reservation_id=reservation.id,
        participant_id=participant.id,
        participant_name=participant.full_name,
        amount=reservation.total_amount,
        method=reservation.payment_method,
        paid_at=reservation.payment_date,
    )
    db.add(transaction)
    add_log(db, "MARK_AS_PAID", f"reservation_id={reservation_id}", actor=current_user.email)
    db.commit()
    return {"status": reservation.status, "transaction_id": transaction.id}


@router.patch("/{reservation_id}/move")
def move_reservation(
    reservation_id: str,
    payload: MoveReservationInput,
    db: Session = Depends(get_db),
    current_user=Depends(require_permission("reservations:move")),
):
    reservation = get_by_id(db, reservation_id)
    if not reservation:
        raise HTTPException(status_code=404, detail="Reserva não encontrada")
    unit = db.get(Unit, payload.unit_id)
    if not unit:
        raise HTTPException(status_code=404, detail="Unidade não encontrada")
    if unit.type_key != reservation.accommodation_type_key:
        raise HTTPException(status_code=400, detail="Unidade incompatível com a acomodação da reserva")
    active_count = db.scalar(
        select(func.count(Reservation.id)).where(
            Reservation.unit_id == unit.id,
            Reservation.status != "cancelada",
            Reservation.id != reservation.id,
        )
    ) or 0
    if active_count >= unit.capacity:
        raise HTTPException(status_code=409, detail="Unidade sem capacidade disponível")
    reservation.unit_id = unit.id
    if reservation.status == "lista_espera":
        reservation.status = "pendente"
    add_log(db, "MOVE_RESERVATION", f"reservation_id={reservation_id};unit_id={unit.id}", actor=current_user.email)
    db.commit()
    return {"status": reservation.status, "unit_id": reservation.unit_id}
