from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.api.deps import get_db, require_permission
from app.crud.participant import get_by_cpf, list_all
from app.models.accommodation import AccommodationType
from app.models.reservation import Reservation
from app.schemas.participant import ParticipantCreate
from app.services.reservation_service import create_participant_with_reservation

router = APIRouter()


@router.get("/")
def read_participants(
    search: str | None = Query(default=None),
    db: Session = Depends(get_db),
    current_user=Depends(require_permission("participants:read")),
):
    participants = list_all(db)
    rows = []
    for p in participants:
        acc = db.get(AccommodationType, p.accommodation_type_key)
        reservation = db.scalar(select(Reservation).where(Reservation.participant_id == p.id))
        rows.append({
            "id": p.id,
            "full_name": p.full_name,
            "birth_date": p.birth_date,
            "age": p.age,
            "cpf": p.cpf,
            "phone": p.phone,
            "gender": p.gender,
            "restrictions": p.restrictions,
            "pcd": p.pcd,
            "notes": p.notes,
            "companion_preference": p.companion_preference,
            "accommodation_type": acc.key,
            "accommodation_type_name": acc.name,
            "reservation_id": reservation.id if reservation else None,
            "created_at": p.created_at,
        })
    if search:
        s = search.lower()
        rows = [x for x in rows if s in f'{x["full_name"]} {x["cpf"]} {x["phone"]} {x["accommodation_type_name"]}'.lower()]
    return rows


@router.post("/")
def create_participant(
    payload: ParticipantCreate,
    db: Session = Depends(get_db),
    current_user=Depends(require_permission("participants:write")),
):
    if get_by_cpf(db, payload.cpf):
        raise HTTPException(status_code=409, detail="CPF já cadastrado")
    try:
        participant, reservation, transaction, acc, unit = create_participant_with_reservation(db, payload)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {
        "participant": {
            "id": participant.id,
            "full_name": participant.full_name,
            "birth_date": participant.birth_date,
            "age": participant.age,
            "cpf": participant.cpf,
            "phone": participant.phone,
            "gender": participant.gender,
            "restrictions": participant.restrictions,
            "pcd": participant.pcd,
            "notes": participant.notes,
            "companion_preference": participant.companion_preference,
            "accommodation_type": acc.key,
            "accommodation_type_name": acc.name,
            "reservation_id": reservation.id,
            "created_at": participant.created_at,
        },
        "reservation": {
            "id": reservation.id,
            "participant_id": participant.id,
            "participant_name": participant.full_name,
            "accommodation_type": acc.key,
            "accommodation_type_name": acc.name,
            "unit_id": reservation.unit_id,
            "unit_label": unit.label if unit else (acc.name if acc.unit_type == "bed" else None),
            "total_amount": reservation.total_amount,
            "installment_count": reservation.installment_count,
            "payment_method": reservation.payment_method,
            "payment_date": reservation.payment_date,
            "amount_paid": reservation.amount_paid,
            "status": reservation.status,
            "created_at": reservation.created_at,
        },
        "transaction": None if not transaction else {
            "id": transaction.id,
            "reservation_id": transaction.reservation_id,
            "participant_id": transaction.participant_id,
            "participant_name": transaction.participant_name,
            "amount": transaction.amount,
            "method": transaction.method,
            "paid_at": transaction.paid_at,
        },
    }
