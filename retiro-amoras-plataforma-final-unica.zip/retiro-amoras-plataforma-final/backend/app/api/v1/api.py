from fastapi import APIRouter
from app.api.v1.endpoints import auth, audit, dashboard, finance, meals, participants, reservations, units, tenants, billing

api_router = APIRouter()
api_router.include_router(auth.router, prefix="/auth", tags=["auth"])
api_router.include_router(participants.router, prefix="/participants", tags=["participants"])
api_router.include_router(reservations.router, prefix="/reservations", tags=["reservations"])
api_router.include_router(finance.router, prefix="/finance", tags=["finance"])
api_router.include_router(meals.router, prefix="/meals", tags=["meals"])
api_router.include_router(units.router, prefix="/units", tags=["units"])
api_router.include_router(dashboard.router, prefix="/dashboard", tags=["dashboard"])
api_router.include_router(audit.router, prefix="/audit", tags=["audit"])


api_router.include_router(tenants.router, prefix="/tenants", tags=["tenants"])
api_router.include_router(billing.router, prefix="/billing", tags=["billing"])
