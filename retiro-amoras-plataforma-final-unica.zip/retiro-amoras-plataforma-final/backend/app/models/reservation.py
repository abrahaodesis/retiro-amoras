import uuid
from datetime import date, datetime
from sqlalchemy import Date, DateTime, Float, ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db.base import Base


class Reservation(Base):
    __tablename__ = "reservations"

    id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: str(uuid.uuid4()))
    participant_id: Mapped[str] = mapped_column(ForeignKey("participants.id"), nullable=False, unique=True, index=True)
    accommodation_type_key: Mapped[str] = mapped_column(ForeignKey("accommodation_types.key"), nullable=False, index=True)
    unit_id: Mapped[str | None] = mapped_column(ForeignKey("units.id"), nullable=True, index=True)
    total_amount: Mapped[float] = mapped_column(Float, nullable=False)
    installment_count: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    payment_method: Mapped[str] = mapped_column(String(40), nullable=False)
    payment_date: Mapped[date] = mapped_column(Date, nullable=False)
    amount_paid: Mapped[float] = mapped_column(Float, nullable=False, default=0)
    status: Mapped[str] = mapped_column(String(30), nullable=False, default="pendente")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    participant = relationship("Participant", back_populates="reservation")
    transactions = relationship("Transaction", back_populates="reservation")
