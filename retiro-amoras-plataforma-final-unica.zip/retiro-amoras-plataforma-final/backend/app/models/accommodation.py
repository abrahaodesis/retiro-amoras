from typing import Optional
from sqlalchemy import Float, ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db.base import Base


class AccommodationType(Base):
    __tablename__ = "accommodation_types"

    key: Mapped[str] = mapped_column(String(50), primary_key=True)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    quantity: Mapped[int] = mapped_column(Integer, nullable=False)
    price: Mapped[float] = mapped_column(Float, nullable=False)
    capacity: Mapped[int] = mapped_column(Integer, nullable=False)
    unit_type: Mapped[str] = mapped_column(String(20), nullable=False)
    gender: Mapped[Optional[str]] = mapped_column(String(1), nullable=True)

    units = relationship("Unit", back_populates="accommodation_type")


class Unit(Base):
    __tablename__ = "units"

    id: Mapped[str] = mapped_column(String(80), primary_key=True)
    type_key: Mapped[str] = mapped_column(ForeignKey("accommodation_types.key"), nullable=False, index=True)
    label: Mapped[str] = mapped_column(String(140), nullable=False)
    capacity: Mapped[int] = mapped_column(Integer, nullable=False)

    accommodation_type = relationship("AccommodationType", back_populates="units")
