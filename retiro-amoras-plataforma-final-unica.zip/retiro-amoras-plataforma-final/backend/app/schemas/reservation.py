from pydantic import BaseModel


class MoveReservationInput(BaseModel):
    unit_id: str
