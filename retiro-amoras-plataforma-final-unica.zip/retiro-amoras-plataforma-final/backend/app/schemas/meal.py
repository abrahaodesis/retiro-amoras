from datetime import date
from pydantic import BaseModel


class MealDispenseCreate(BaseModel):
    participant_id: str
    day: date
    meal: str
