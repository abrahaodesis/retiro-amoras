from datetime import date, datetime
import re
from pydantic import BaseModel, Field, field_validator


def digits_only(value: str) -> str:
    return re.sub(r"\D", "", value or "")


def validate_cpf(cpf: str) -> bool:
    s = digits_only(cpf)
    if len(s) != 11 or len(set(s)) == 1:
        return False
    total = sum(int(s[i]) * (10 - i) for i in range(9))
    d1 = (total * 10) % 11
    d1 = 0 if d1 == 10 else d1
    if d1 != int(s[9]):
        return False
    total = sum(int(s[i]) * (11 - i) for i in range(10))
    d2 = (total * 10) % 11
    d2 = 0 if d2 == 10 else d2
    return d2 == int(s[10])


class ParticipantCreate(BaseModel):
    full_name: str = Field(..., min_length=3)
    birth_date: date
    cpf: str
    phone: str
    gender: str = Field(..., pattern=r"^(M|F)$")
    restrictions: str = ""
    pcd: str = ""
    notes: str = ""
    companion_preference: str = ""
    accommodation_type: str
    payment_amount: float = Field(..., gt=0)
    installment_count: int = Field(1, ge=1)
    payment_method: str
    payment_date: date
    paid_now: bool = True

    @field_validator("cpf")
    @classmethod
    def cpf_is_valid(cls, value: str) -> str:
        if not validate_cpf(value):
            raise ValueError("CPF inválido")
        return value

    @field_validator("phone")
    @classmethod
    def phone_is_valid(cls, value: str) -> str:
        if len(digits_only(value)) < 10:
            raise ValueError("Celular inválido")
        return value
