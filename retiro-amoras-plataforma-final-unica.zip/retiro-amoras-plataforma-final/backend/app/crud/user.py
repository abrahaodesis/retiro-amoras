from sqlalchemy import select
from sqlalchemy.orm import Session
from app.core.security import get_password_hash
from app.models.user import User


def get_user_by_email(db: Session, email: str):
    return db.scalar(select(User).where(User.email == email))


def create_user(db: Session, email: str, password: str, full_name: str, role: str):
    user = User(
        email=email,
        hashed_password=get_password_hash(password),
        full_name=full_name,
        role=role,
        is_active=True,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user
