from sqlalchemy import select
from sqlalchemy.orm import Session
from app.models.reservation import Reservation


def get_by_id(db: Session, reservation_id: str):
    return db.get(Reservation, reservation_id)


def list_all(db: Session):
    return db.scalars(select(Reservation).order_by(Reservation.created_at.desc())).all()
