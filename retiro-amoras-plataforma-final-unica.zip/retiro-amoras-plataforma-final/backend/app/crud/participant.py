from sqlalchemy import select
from sqlalchemy.orm import Session
from app.models.participant import Participant


def get_by_cpf(db: Session, cpf: str):
    return db.scalar(select(Participant).where(Participant.cpf == cpf))


def list_all(db: Session):
    return db.scalars(select(Participant).order_by(Participant.created_at.desc())).all()
