from sqlalchemy import select
from sqlalchemy.orm import Session
from app.models.transaction import Transaction


def list_all(db: Session):
    return db.scalars(select(Transaction).order_by(Transaction.created_at.desc())).all()
