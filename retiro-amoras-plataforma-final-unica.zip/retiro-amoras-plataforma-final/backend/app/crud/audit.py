from sqlalchemy import select
from sqlalchemy.orm import Session
from app.models.audit import AuditLog


def add_log(db: Session, action: str, payload: str, actor: str = "system"):
    log = AuditLog(action=action, payload=payload, actor=actor)
    db.add(log)
    return log


def list_all(db: Session):
    return db.scalars(select(AuditLog).order_by(AuditLog.created_at.desc())).all()
