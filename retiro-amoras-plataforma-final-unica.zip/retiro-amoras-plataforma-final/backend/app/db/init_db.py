from sqlalchemy import func, select
from app.core.config import settings
from app.core.security import get_password_hash
from app.db.base import Base
from app.db.session import SessionLocal, engine
from app.models.accommodation import AccommodationType, Unit
from app.models.user import User

SEED_ACCOMMODATIONS = [
    {"key": "duplo", "name": "Apartamento Duplo", "quantity": 18, "price": 4000, "capacity": 2, "unit_type": "apartment", "gender": None},
    {"key": "triplo", "name": "Apartamento Triplo", "quantity": 25, "price": 5400, "capacity": 3, "unit_type": "apartment", "gender": None},
    {"key": "quadruplo", "name": "Apartamento Quádruplo", "quantity": 18, "price": 6600, "capacity": 4, "unit_type": "apartment", "gender": None},
    {"key": "quintuplo", "name": "Apartamento Quíntuplo", "quantity": 3, "price": 7500, "capacity": 5, "unit_type": "apartment", "gender": None},
    {"key": "suite_master", "name": "Suíte Master", "quantity": 2, "price": 6500, "capacity": 2, "unit_type": "apartment", "gender": None},
    {"key": "aloj_fem", "name": "Alojamento Feminino", "quantity": 30, "price": 1300, "capacity": 1, "unit_type": "bed", "gender": "F"},
    {"key": "aloj_masc", "name": "Alojamento Masculino", "quantity": 30, "price": 1300, "capacity": 1, "unit_type": "bed", "gender": "M"},
]


def init_db():
    Base.metadata.create_all(bind=engine)
    with SessionLocal() as db:
        user_count = db.scalar(select(func.count(User.id))) or 0
        if user_count == 0:
            db.add(User(
                email=settings.FIRST_SUPERUSER_EMAIL,
                hashed_password=get_password_hash(settings.FIRST_SUPERUSER_PASSWORD),
                full_name="Administrador Master",
                role="admin",
                is_active=True,
            ))
            db.commit()

        accommodation_count = db.scalar(select(func.count(AccommodationType.key))) or 0
        if accommodation_count == 0:
            for item in SEED_ACCOMMODATIONS:
                db.add(AccommodationType(**item))
            db.commit()

            for item in SEED_ACCOMMODATIONS:
                if item["unit_type"] == "apartment":
                    for i in range(1, item["quantity"] + 1):
                        db.add(Unit(
                            id=f'{item["key"]}_{i}',
                            type_key=item["key"],
                            label=f'{item["name"]} {str(i).zfill(2)}',
                            capacity=item["capacity"],
                        ))
            db.commit()
