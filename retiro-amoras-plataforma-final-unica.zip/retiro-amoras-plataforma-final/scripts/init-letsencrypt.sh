#!/usr/bin/env sh
set -e

if [ -z "$DOMAIN" ] || [ -z "$EMAIL" ]; then
  echo "Defina DOMAIN e EMAIL no arquivo .env"
  exit 1
fi

mkdir -p ./gateway/certbot/conf
mkdir -p ./gateway/www

docker compose up -d nginx

docker compose run --rm certbot certonly --webroot   --webroot-path /var/www/certbot   --email "$EMAIL"   --agree-tos   --no-eff-email   -d "$DOMAIN"

docker compose exec nginx nginx -s reload
echo "Certificado inicial emitido para $DOMAIN"
