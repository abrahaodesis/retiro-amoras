#!/usr/bin/env bash
set -e

APP_PATH="${1:-/opt/retiro-amoras}"

mkdir -p "$APP_PATH/releases"
mkdir -p "$APP_PATH/shared"

echo "Estrutura criada em:"
echo "$APP_PATH/releases"
echo "$APP_PATH/shared"

echo "Crie manualmente:"
echo "- $APP_PATH/shared/.env"
echo "- $APP_PATH/shared/backend.env"
