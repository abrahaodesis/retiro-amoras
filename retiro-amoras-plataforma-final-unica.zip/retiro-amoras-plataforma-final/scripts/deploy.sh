#!/usr/bin/env bash
set -e

echo "Subindo stack em produção..."
docker compose down
docker compose up -d --build

echo "Deploy concluído."
