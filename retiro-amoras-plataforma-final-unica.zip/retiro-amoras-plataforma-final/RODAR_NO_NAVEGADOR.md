# Rodar no navegador

## Local
### backend
```bash
cd backend
cp .env.example .env
pip install -r requirements.txt
alembic upgrade head
uvicorn app.main:app --reload
```

### frontend
```bash
cd frontend
npm install
npm run dev
```

Abrir:
```bash
http://localhost:5173
```

## Produção
Use as versões com Docker/Nginx/HTTPS já incluídas no projeto e configure o domínio.
