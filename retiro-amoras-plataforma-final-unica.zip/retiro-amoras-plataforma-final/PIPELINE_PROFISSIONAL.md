# Pipeline profissional: staging, produção e rollback

## Workflows incluídos

- `.github/workflows/ci.yml`
- `.github/workflows/deploy-staging.yml`
- `.github/workflows/deploy-production.yml`
- `.github/workflows/rollback-production.yml`

## Estratégia

### CI
Executa:
- validação do backend
- build do frontend
- empacotamento da release

### Staging
- dispara em `develop`
- publica no servidor de staging
- usa estrutura `releases/` + `current`

### Produção
- disparo manual ou por branch principal
- exige `environment: production`
- faz deploy em release isolada
- atualiza o symlink `current`
- executa healthcheck
- se falhar, tenta rollback automático para a release anterior

### Rollback manual
- workflow dedicado
- recebe uma release alvo
- recoloca o symlink em `releases/<TARGET>`
- sobe novamente os containers

## Secrets necessários

### Staging
- `STAGING_SSH_HOST`
- `STAGING_SSH_USER`
- `STAGING_SSH_PRIVATE_KEY`
- `STAGING_SSH_PORT`
- `STAGING_DEPLOY_PATH`

### Produção
- `PROD_SSH_HOST`
- `PROD_SSH_USER`
- `PROD_SSH_PRIVATE_KEY`
- `PROD_SSH_PORT`
- `PROD_DEPLOY_PATH`
- `PROD_HEALTHCHECK_URL`

## Exemplo de healthcheck

```bash
https://seu-dominio.com/api/v1/health
```

## Environments no GitHub

Crie:
- `staging`
- `production`

No environment `production`, ative aprovação manual para aumentar segurança.

## Estrutura recomendada de branches

- `develop` -> staging
- `main` -> produção

## Observações

- O rollback automático depende da existência da release anterior.
- O rollback manual permite voltar para qualquer release disponível.
- O deploy usa symlink `current`, o que facilita reversão.
