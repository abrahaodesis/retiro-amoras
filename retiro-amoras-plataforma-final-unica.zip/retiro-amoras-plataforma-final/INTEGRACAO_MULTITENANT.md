# Como integrar o patch multi-tenant

## 1. Criar o modelo Tenant
Copie:
- `app/models/tenant.py`
- `app/models/mixins.py`

## 2. Adicionar `tenant_id` nos modelos de domínio
Exemplo:
```python
class Participant(Base, TenantMixin):
    ...
```

## 3. Adicionar middleware
Registrar:
- `TenantResolverMiddleware`

## 4. JWT com tenant
Trocar geração do token para incluir:
- `tenant_id`
- `role`

## 5. Dependência obrigatória
Use:
- `get_current_tenant`

## 6. Filtrar queries
Sempre:
```python
.where(Model.tenant_id == current_tenant.id)
```

## 7. Rodar migration
Aplicar `0002_multitenant_base.py`

## 8. Migrar dados antigos
- criar tenant default
- preencher `tenant_id`
- tornar coluna NOT NULL
