# Versão única final — multi-tenant + billing incorporados

## O que esta versão adiciona à base principal
- suporte a tenant
- modelo `Tenant`
- `tenant_id` nas entidades principais (patch incluído)
- endpoints de tenants
- planos, assinaturas e pagamentos
- bloqueio por assinatura
- limites por plano
- branding da Igreja Batista Lírio Armação

## Ordem recomendada de ativação técnica
1. aplicar migrations:
   - `0002_multitenant_base.py`
   - `0003_billing_module.py`
2. ajustar modelos principais para herdar `TenantMixin`
3. registrar middleware `TenantResolverMiddleware`
4. ajustar geração de JWT para conter `tenant_id`
5. filtrar queries por tenant
6. registrar rotas:
   - `/api/v1/tenants`
   - `/api/v1/billing`

## Resultado de produto
Esta base única já aponta para a evolução SaaS:
- várias igrejas/clientes
- isolamento por tenant
- monetização por plano

## Observação importante
Os patches foram incorporados ao pacote principal como código e documentação.
A aplicação de `tenant_id` em **todas** as queries do domínio deve ser feita com rigor antes da publicação multi-cliente.
