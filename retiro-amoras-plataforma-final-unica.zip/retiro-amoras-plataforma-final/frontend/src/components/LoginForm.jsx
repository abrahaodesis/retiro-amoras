import React, { useState } from 'react'
import { Button, Card, Container, Input, Page, Subtitle, Title } from './UI'
import { useAuth } from '../contexts/AuthContext'

export default function LoginForm() {
  const { login, loading } = useAuth()
  const [email, setEmail] = useState('admin@amoras.local')
  const [password, setPassword] = useState('Admin@123')
  const [error, setError] = useState('')

  const onSubmit = async (e) => {
    e.preventDefault()
    setError('')
    const result = await login(email, password)
    if (!result.ok) setError(result.message)
  }

  return (
    <Page>
      <Container>
        <div style={{ maxWidth: 420, margin: '80px auto 0' }}>
          <Card>
            <div style={{ display: 'grid', gap: 12 }}>
              <div style={{ display: 'flex', justifyContent: 'center' }}><img src="/logo-ibla.png" alt="Igreja Batista Lírio Armação" style={{ width: 110, height: 110, objectFit: 'contain' }} /></div>
              <Title>Retiro Espiritual 2027</Title>
              <Subtitle>Igreja Batista Lírio Armação • Painel administrativo do Hotel Fazenda Amoras.</Subtitle>
              <form onSubmit={onSubmit} style={{ display: 'grid', gap: 14 }}>
                <Input label="E-mail" value={email} onChange={(e) => setEmail(e.target.value)} />
                <Input label="Senha" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
                {error ? <div style={{ color: '#dc2626', fontSize: 14 }}>{error}</div> : null}
                <Button type="submit" disabled={loading}>{loading ? 'Entrando...' : 'Entrar'}</Button>
              </form>
            </div>
          </Card>
        </div>
      </Container>
    </Page>
  )
}
