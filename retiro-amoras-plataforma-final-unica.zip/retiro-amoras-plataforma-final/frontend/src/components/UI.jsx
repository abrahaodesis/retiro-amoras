import React from 'react'

export function Page({ children }) {
  return <div style={{ minHeight: '100vh', padding: 24, background: '#f8fafc' }}>{children}</div>
}

export function Container({ children }) {
  return <div style={{ maxWidth: 1280, margin: '0 auto', display: 'grid', gap: 16 }}>{children}</div>
}

export function Card({ children, style = {} }) {
  return <div style={{ background: '#fff', border: '1px solid #e2e8f0', borderRadius: 18, padding: 20, ...style }}>{children}</div>
}

export function Title({ children }) {
  return <h1 style={{ margin: 0, fontSize: 30 }}>{children}</h1>
}

export function Subtitle({ children }) {
  return <p style={{ margin: 0, color: '#475569' }}>{children}</p>
}

export function Grid({ children, columns = 2 }) {
  return <div style={{ display: 'grid', gap: 16, gridTemplateColumns: `repeat(${columns}, minmax(0, 1fr))` }}>{children}</div>
}

export function Input({ label, error, ...props }) {
  return (
    <label style={{ display: 'grid', gap: 8 }}>
      <span style={{ fontWeight: 600 }}>{label}</span>
      <input {...props} style={{ padding: 12, borderRadius: 12, border: '1px solid #cbd5e1' }} />
      {error ? <span style={{ color: '#dc2626', fontSize: 13 }}>{error}</span> : null}
    </label>
  )
}

export function TextArea({ label, error, ...props }) {
  return (
    <label style={{ display: 'grid', gap: 8 }}>
      <span style={{ fontWeight: 600 }}>{label}</span>
      <textarea {...props} style={{ padding: 12, borderRadius: 12, border: '1px solid #cbd5e1', minHeight: 90 }} />
      {error ? <span style={{ color: '#dc2626', fontSize: 13 }}>{error}</span> : null}
    </label>
  )
}

export function Select({ label, error, children, ...props }) {
  return (
    <label style={{ display: 'grid', gap: 8 }}>
      <span style={{ fontWeight: 600 }}>{label}</span>
      <select {...props} style={{ padding: 12, borderRadius: 12, border: '1px solid #cbd5e1' }}>
        {children}
      </select>
      {error ? <span style={{ color: '#dc2626', fontSize: 13 }}>{error}</span> : null}
    </label>
  )
}

export function Button({ children, variant = 'primary', ...props }) {
  const styles = variant === 'secondary'
    ? { background: '#fff', color: '#0f172a', border: '1px solid #cbd5e1' }
    : variant === 'danger'
    ? { background: '#dc2626', color: '#fff', border: '1px solid #dc2626' }
    : { background: '#0f172a', color: '#fff', border: '1px solid #0f172a' }

  return (
    <button
      {...props}
      style={{
        padding: '12px 16px',
        borderRadius: 12,
        cursor: 'pointer',
        fontWeight: 700,
        ...styles
      }}
    >
      {children}
    </button>
  )
}

export function Badge({ children, tone = 'default' }) {
  const bg = tone === 'danger' ? '#fee2e2' : tone === 'success' ? '#dcfce7' : '#e2e8f0'
  const color = tone === 'danger' ? '#991b1b' : tone === 'success' ? '#166534' : '#334155'
  return <span style={{ background: bg, color, padding: '6px 10px', borderRadius: 999, fontSize: 12, fontWeight: 700 }}>{children}</span>
}

export function Table({ columns, rows, renderRow }) {
  return (
    <div style={{ overflowX: 'auto' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr>
            {columns.map((col) => (
              <th key={col} style={{ textAlign: 'left', padding: 12, borderBottom: '1px solid #e2e8f0' }}>{col}</th>
            ))}
          </tr>
        </thead>
        <tbody>{rows.map(renderRow)}</tbody>
      </table>
    </div>
  )
}
