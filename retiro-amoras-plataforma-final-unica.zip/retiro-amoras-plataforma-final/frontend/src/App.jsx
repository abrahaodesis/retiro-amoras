import React, { useEffect, useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import { Users, Wallet, BedDouble, UtensilsCrossed, LogOut, RefreshCw } from 'lucide-react'
import { api } from './lib/api'
import { useAuth } from './contexts/AuthContext'
import LoginForm from './components/LoginForm'
import { Badge, Button, Card, Container, Grid, Input, Page, Select, Subtitle, Table, TextArea, Title } from './components/UI'

const ACCOMMODATION_TYPES = [
  { key: 'duplo', name: 'Apartamento Duplo', price: 4000, gender: '' },
  { key: 'triplo', name: 'Apartamento Triplo', price: 5400, gender: '' },
  { key: 'quadruplo', name: 'Apartamento Quádruplo', price: 6600, gender: '' },
  { key: 'quintuplo', name: 'Apartamento Quíntuplo', price: 7500, gender: '' },
  { key: 'suite_master', name: 'Suíte Master', price: 6500, gender: '' },
  { key: 'aloj_fem', name: 'Alojamento Feminino', price: 1300, gender: 'F' },
  { key: 'aloj_masc', name: 'Alojamento Masculino', price: 1300, gender: 'M' }
]

const MEAL_TYPES = ['Café da manhã', 'Almoço', 'Jantar', 'Lanche']
const EVENT_DAYS = ['2027-02-05','2027-02-06','2027-02-07','2027-02-08','2027-02-09','2027-02-10']

function currency(v) {
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(Number(v || 0))
}

function cpfMask(value) {
  const digits = value.replace(/\D/g, '').slice(0, 11)
  return digits.replace(/(\d{3})(\d)/, '$1.$2').replace(/(\d{3})(\d)/, '$1.$2').replace(/(\d{3})(\d{1,2})$/, '$1-$2')
}

function phoneMask(value) {
  const digits = value.replace(/\D/g, '').slice(0, 11)
  if (digits.length <= 10) return digits.replace(/(\d{2})(\d)/, '($1) $2').replace(/(\d{4})(\d)/, '$1-$2')
  return digits.replace(/(\d{2})(\d)/, '($1) $2').replace(/(\d{5})(\d)/, '$1-$2')
}

function validateCPF(cpf) {
  const s = cpf.replace(/\D/g, '')
  if (s.length !== 11 || /^(\d)\1+$/.test(s)) return false
  let sum = 0
  for (let i = 0; i < 9; i++) sum += Number(s[i]) * (10 - i)
  let d1 = (sum * 10) % 11
  if (d1 === 10) d1 = 0
  if (d1 !== Number(s[9])) return false
  sum = 0
  for (let i = 0; i < 10; i++) sum += Number(s[i]) * (11 - i)
  let d2 = (sum * 10) % 11
  if (d2 === 10) d2 = 0
  return d2 === Number(s[10])
}

const initialForm = {
  fullName: '',
  birthDate: '',
  cpf: '',
  phone: '',
  gender: '',
  restrictions: '',
  pcd: '',
  notes: '',
  companionPreference: '',
  accommodationType: '',
  paymentAmount: '',
  installmentCount: '1',
  paymentMethod: '',
  paymentDate: '',
  paidNow: true
}

export default function App() {
  const { isAuthenticated, user, logout } = useAuth()
  const [tab, setTab] = useState('dashboard')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [dashboard, setDashboard] = useState(null)
  const [participants, setParticipants] = useState([])
  const [reservations, setReservations] = useState([])
  const [transactions, setTransactions] = useState([])
  const [units, setUnits] = useState([])
  const [dispenses, setDispenses] = useState([])
  const [audit, setAudit] = useState([])
  const [search, setSearch] = useState('')
  const [form, setForm] = useState(initialForm)
  const [formErrors, setFormErrors] = useState({})

  const canWriteParticipants = user?.role === 'admin' || user?.role === 'financeiro'
  const canFinance = user?.role === 'admin' || user?.role === 'financeiro'
  const canMove = user?.role === 'admin' || user?.role === 'hospedagem'
  const canMeals = user?.role === 'admin' || user?.role === 'alimentacao'
  const canAudit = user?.role === 'admin'

  const loadData = async () => {
    if (!isAuthenticated) return
    setLoading(true)
    setError('')
    try {
      const requests = [
        api.get('/dashboard'),
        api.get('/participants'),
        api.get('/reservations')
      ]

      if (canFinance) requests.push(api.get('/finance/transactions'))
      else requests.push(Promise.resolve({ data: [] }))

      if (user?.role === 'admin' || user?.role === 'hospedagem') requests.push(api.get('/units'))
      else requests.push(Promise.resolve({ data: [] }))

      if (canMeals) {
        requests.push(api.get('/meals/dispenses'))
        requests.push(api.get('/audit').catch(() => ({ data: [] })))
      } else {
        requests.push(Promise.resolve({ data: [] }))
        requests.push(canAudit ? api.get('/audit') : Promise.resolve({ data: [] }))
      }

      const [dashRes, partRes, resRes, txRes, unitsRes, dispRes, auditRes] = await Promise.all(requests)
      setDashboard(dashRes.data)
      setParticipants(partRes.data)
      setReservations(resRes.data)
      setTransactions(txRes.data)
      setUnits(unitsRes.data)
      setDispenses(dispRes.data)
      setAudit(auditRes.data)
    } catch (e) {
      setError(e?.response?.data?.detail || 'Falha ao carregar dados')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadData()
  }, [isAuthenticated, user?.role])

  const occupancy = dashboard?.occupancy || []
  const finance = dashboard?.finance || { total_contracted: 0, total_received: 0, total_pending: 0, pending_count: 0 }
  const mealProjection = dashboard?.meals || []
  const kpis = dashboard?.kpis || { total_participants: 0, paid: 0, pending: 0, waitlist: 0 }

  const filteredParticipants = useMemo(() => {
    const s = search.toLowerCase()
    return participants.filter((p) => [p.full_name, p.cpf, p.phone, p.accommodation_type_name].join(' ').toLowerCase().includes(s))
  }, [participants, search])

  const remainingForType = (typeKey) => occupancy.find((x) => x.key === typeKey)?.remaining ?? 0

  const validateForm = () => {
    const e = {}
    if (!form.fullName.trim()) e.fullName = 'Informe o nome completo'
    if (!form.birthDate) e.birthDate = 'Informe a data de nascimento'
    if (!validateCPF(form.cpf)) e.cpf = 'CPF inválido'
    if (form.phone.replace(/\D/g, '').length < 10) e.phone = 'Celular inválido'
    if (!form.gender) e.gender = 'Selecione o sexo'
    if (!form.accommodationType) e.accommodationType = 'Selecione a acomodação'
    if (!form.paymentAmount || Number(form.paymentAmount) <= 0) e.paymentAmount = 'Informe o valor'
    if (!form.paymentMethod) e.paymentMethod = 'Selecione a forma de pagamento'
    if (!form.paymentDate) e.paymentDate = 'Informe a data do pagamento'
    const acc = ACCOMMODATION_TYPES.find((a) => a.key === form.accommodationType)
    if (acc?.gender && acc.gender !== form.gender) e.accommodationType = 'Alojamento incompatível com o sexo informado'
    if (remainingForType(form.accommodationType) <= 0) e.accommodationType = 'Esta acomodação está esgotada'
    setFormErrors(e)
    return Object.keys(e).length === 0
  }

  const createParticipant = async () => {
    if (!validateForm()) return
    setLoading(true)
    setError('')
    try {
      await api.post('/participants', {
        full_name: form.fullName,
        birth_date: form.birthDate,
        cpf: form.cpf,
        phone: form.phone,
        gender: form.gender,
        restrictions: form.restrictions,
        pcd: form.pcd,
        notes: form.notes,
        companion_preference: form.companionPreference,
        accommodation_type: form.accommodationType,
        payment_amount: Number(form.paymentAmount),
        installment_count: Number(form.installmentCount),
        payment_method: form.paymentMethod,
        payment_date: form.paymentDate,
        paid_now: form.paidNow
      })
      setForm(initialForm)
      setFormErrors({})
      setTab('reservas')
      await loadData()
    } catch (e) {
      setError(e?.response?.data?.detail || 'Falha ao salvar inscrição')
    } finally {
      setLoading(false)
    }
  }

  const cancelReservation = async (id) => {
    setLoading(true)
    setError('')
    try {
      await api.patch(`/reservations/${id}/cancel`)
      await loadData()
    } catch (e) {
      setError(e?.response?.data?.detail || 'Falha ao cancelar reserva')
    } finally {
      setLoading(false)
    }
  }

  const payReservation = async (id) => {
    setLoading(true)
    setError('')
    try {
      await api.patch(`/reservations/${id}/pay`)
      await loadData()
    } catch (e) {
      setError(e?.response?.data?.detail || 'Falha ao quitar reserva')
    } finally {
      setLoading(false)
    }
  }

  const moveReservation = async (id, unitId) => {
    setLoading(true)
    setError('')
    try {
      await api.patch(`/reservations/${id}/move`, { unit_id: unitId })
      await loadData()
    } catch (e) {
      setError(e?.response?.data?.detail || 'Falha ao mover participante')
    } finally {
      setLoading(false)
    }
  }

  const toggleMeal = async (participantId, day, meal) => {
    setLoading(true)
    setError('')
    try {
      await api.post('/meals/dispense', { participant_id: participantId, day, meal })
      await loadData()
    } catch (e) {
      setError(e?.response?.data?.detail || 'Falha ao atualizar refeição')
    } finally {
      setLoading(false)
    }
  }

  const isDispensed = (participantId, day, meal) => {
    return dispenses.some((x) => x.participant_id === participantId && String(x.day).slice(0, 10) === day && x.meal === meal)
  }

  if (!isAuthenticated) return <LoginForm />

  return (
    <Page>
      <Container>
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} style={{ display: 'grid', gap: 10 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', gap: 16, alignItems: 'center', flexWrap: 'wrap' }}>
            <div style={{ display: 'grid', gap: 8 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 14, flexWrap: 'wrap' }}>
                <img src="/logo-ibla.png" alt="Igreja Batista Lírio Armação" style={{ width: 72, height: 72, objectFit: 'contain', borderRadius: 16, background: '#fff', padding: 6, border: '1px solid #e2e8f0' }} />
                <div style={{ display: 'grid', gap: 6 }}>
                  <Title>Retiro Espiritual 2027 • Igreja Batista Lírio Armação</Title>
                  <Subtitle>Aplicativo de inscrições, reservas e gestão do Hotel Fazenda Amoras.</Subtitle>
                </div>
              </div>
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                <Badge>Usuário: {user?.full_name}</Badge>
                <Badge>{user?.role}</Badge>
                <Badge>Evento: 05/02/2027 a 10/02/2027</Badge>
              </div>
            </div>
            <div style={{ display: 'flex', gap: 10 }}>
              <Button variant="secondary" onClick={loadData}><RefreshCw size={16} style={{ marginRight: 6, verticalAlign: 'middle' }} />Atualizar</Button>
              <Button variant="danger" onClick={logout}><LogOut size={16} style={{ marginRight: 6, verticalAlign: 'middle' }} />Sair</Button>
            </div>
          </div>
          {error ? <Card style={{ color: '#991b1b', background: '#fef2f2' }}>{error}</Card> : null}
          {loading ? <Card>Sincronizando...</Card> : null}
        </motion.div>

        <Grid columns={4}>
          <Metric icon={<Users size={20} />} label="Inscritos" value={String(kpis.total_participants)} />
          <Metric icon={<Wallet size={20} />} label="Recebido" value={currency(finance.total_received)} />
          <Metric icon={<BedDouble size={20} />} label="Quitadas" value={String(kpis.paid)} />
          <Metric icon={<UtensilsCrossed size={20} />} label="Pendentes" value={String(kpis.pending)} />
        </Grid>

        <Card>
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
            {['dashboard', 'inscricao', 'reservas', 'ocupacao', 'financeiro', 'refeicoes', 'auditoria'].map((t) => (
              <Button key={t} variant={tab === t ? 'primary' : 'secondary'} onClick={() => setTab(t)}>{t}</Button>
            ))}
          </div>
        </Card>

        {tab === 'dashboard' && (
          <Grid columns={2}>
            <Card>
              <h3>Disponibilidade por acomodação</h3>
              <Table
                columns={['Acomodação', 'Total', 'Usadas', 'Restantes', 'Valor']}
                rows={occupancy}
                renderRow={(row) => (
                  <tr key={row.key}>
                    <td style={td}>{row.name}</td>
                    <td style={td}>{row.quantity}</td>
                    <td style={td}>{row.used}</td>
                    <td style={td}><Badge tone={row.remaining > 0 ? 'success' : 'danger'}>{row.remaining}</Badge></td>
                    <td style={td}>{currency(row.price)}</td>
                  </tr>
                )}
              />
            </Card>
            <Card>
              <h3>Indicadores financeiros</h3>
              <Line label="Total contratado" value={currency(finance.total_contracted)} />
              <Line label="Total recebido" value={currency(finance.total_received)} />
              <Line label="Total pendente" value={currency(finance.total_pending)} />
              <Line label="Reservas pendentes" value={String(finance.pending_count)} />
            </Card>
            <Card style={{ gridColumn: '1 / -1' }}>
              <h3>Projeção de refeições</h3>
              <Table
                columns={['Dia', ...MEAL_TYPES]}
                rows={mealProjection}
                renderRow={(row) => (
                  <tr key={row.day}>
                    <td style={td}>{String(row.day).slice(0,10)}</td>
                    {MEAL_TYPES.map((meal) => <td style={td} key={meal}>{row.per_meal?.[meal] ?? 0}</td>)}
                  </tr>
                )}
              />
            </Card>
          </Grid>
        )}

        {tab === 'inscricao' && (
          <Card>
            <h3>Nova inscrição</h3>
            {!canWriteParticipants ? <div>Seu perfil não pode cadastrar participantes.</div> : (
              <div style={{ display: 'grid', gap: 16 }}>
                <Grid columns={2}>
                  <Input label="Nome completo" value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} error={formErrors.fullName} />
                  <Input label="Data de nascimento" type="date" value={form.birthDate} onChange={(e) => setForm({ ...form, birthDate: e.target.value })} error={formErrors.birthDate} />
                  <Input label="CPF" value={form.cpf} onChange={(e) => setForm({ ...form, cpf: cpfMask(e.target.value) })} error={formErrors.cpf} />
                  <Input label="Celular" value={form.phone} onChange={(e) => setForm({ ...form, phone: phoneMask(e.target.value) })} error={formErrors.phone} />
                  <Select label="Sexo" value={form.gender} onChange={(e) => setForm({ ...form, gender: e.target.value })} error={formErrors.gender}>
                    <option value="">Selecione</option>
                    <option value="M">Masculino</option>
                    <option value="F">Feminino</option>
                  </Select>
                  <Select label="Acomodação" value={form.accommodationType} onChange={(e) => {
                    const value = e.target.value
                    const item = ACCOMMODATION_TYPES.find((x) => x.key === value)
                    setForm({ ...form, accommodationType: value, paymentAmount: item ? String(item.price) : '' })
                  }} error={formErrors.accommodationType}>
                    <option value="">Selecione</option>
                    {occupancy.map((a) => <option key={a.key} value={a.key} disabled={a.remaining <= 0}>{a.name} • Restantes: {a.remaining}</option>)}
                  </Select>
                  <TextArea label="Restrições alimentares" value={form.restrictions} onChange={(e) => setForm({ ...form, restrictions: e.target.value })} />
                  <TextArea label="Necessidades especiais (PCD)" value={form.pcd} onChange={(e) => setForm({ ...form, pcd: e.target.value })} />
                </Grid>
                <TextArea label="Observações adicionais" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
                <Grid columns={2}>
                  <Input label="Preferência de companheiro(a)" value={form.companionPreference} onChange={(e) => setForm({ ...form, companionPreference: e.target.value })} />
                  <Input label="Valor" type="number" value={form.paymentAmount} onChange={(e) => setForm({ ...form, paymentAmount: e.target.value })} error={formErrors.paymentAmount} />
                  <Input label="Parcelas" type="number" min="1" value={form.installmentCount} onChange={(e) => setForm({ ...form, installmentCount: e.target.value })} />
                  <Select label="Forma de pagamento" value={form.paymentMethod} onChange={(e) => setForm({ ...form, paymentMethod: e.target.value })} error={formErrors.paymentMethod}>
                    <option value="">Selecione</option>
                    {['PIX','Cartão','Transferência','Dinheiro','Boleto','Outro'].map((m) => <option key={m} value={m}>{m}</option>)}
                  </Select>
                  <Input label="Data do pagamento" type="date" value={form.paymentDate} onChange={(e) => setForm({ ...form, paymentDate: e.target.value })} error={formErrors.paymentDate} />
                  <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontWeight: 600 }}>
                    <input type="checkbox" checked={form.paidNow} onChange={(e) => setForm({ ...form, paidNow: e.target.checked })} />
                    Pagamento já realizado
                  </label>
                </Grid>
                <div><Button onClick={createParticipant}>Salvar inscrição</Button></div>
              </div>
            )}
          </Card>
        )}

        {tab === 'reservas' && (
          <Card>
            <h3>Reservas e inscritos</h3>
            <div style={{ marginBottom: 14 }}>
              <Input label="Buscar" value={search} onChange={(e) => setSearch(e.target.value)} />
            </div>
            <Table
              columns={['Nome', 'Acomodação', 'Unidade', 'Status', 'Valor', 'Ações']}
              rows={filteredParticipants}
              renderRow={(p) => {
                const r = reservations.find((x) => x.participant_id === p.id)
                return (
                  <tr key={p.id}>
                    <td style={td}>{p.full_name}<div style={{ fontSize: 12, color: '#64748b' }}>{p.cpf} • {p.phone}</div></td>
                    <td style={td}>{p.accommodation_type_name}</td>
                    <td style={td}>{r?.unit_label || '—'}</td>
                    <td style={td}><Badge tone={r?.status === 'quitada' ? 'success' : r?.status === 'cancelada' ? 'danger' : 'default'}>{r?.status || '—'}</Badge></td>
                    <td style={td}>{currency(r?.total_amount || 0)}</td>
                    <td style={td}>
                      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                        {canFinance && r?.status === 'pendente' ? <Button onClick={() => payReservation(r.id)}>Quitar</Button> : null}
                        {(user?.role === 'admin' || user?.role === 'financeiro') && r?.status !== 'cancelada' ? <Button variant="danger" onClick={() => cancelReservation(r.id)}>Cancelar</Button> : null}
                        {canMove && ['duplo','triplo','quadruplo','quintuplo','suite_master'].includes(r?.accommodation_type) ? (
                          <MoveSelector reservation={r} units={units.filter((u) => u.type_key === r.accommodation_type)} onMove={moveReservation} />
                        ) : null}
                      </div>
                    </td>
                  </tr>
                )
              }}
            />
          </Card>
        )}

        {tab === 'ocupacao' && (
          <Grid columns={3}>
            {units.map((unit) => (
              <Card key={unit.id}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <strong>{unit.label}</strong>
                  <Badge>{unit.occupants.length}/{unit.capacity}</Badge>
                </div>
                <div style={{ display: 'grid', gap: 8, marginTop: 12 }}>
                  {unit.occupants.length === 0 ? <span style={{ color: '#64748b' }}>Sem ocupantes</span> : unit.occupants.map((pid) => {
                    const p = participants.find((x) => x.id === pid)
                    return <Card key={pid} style={{ padding: 12 }}>{p?.full_name || pid}</Card>
                  })}
                </div>
              </Card>
            ))}
          </Grid>
        )}

        {tab === 'financeiro' && (
          <Card>
            <h3>Financeiro</h3>
            {!canFinance ? <div>Seu perfil não pode visualizar o financeiro.</div> : (
              <Table
                columns={['Participante', 'Valor', 'Forma', 'Data']}
                rows={transactions}
                renderRow={(t) => (
                  <tr key={t.id}>
                    <td style={td}>{t.participant_name}</td>
                    <td style={td}>{currency(t.amount)}</td>
                    <td style={td}>{t.method}</td>
                    <td style={td}>{String(t.paid_at).slice(0,10)}</td>
                  </tr>
                )}
              />
            )}
          </Card>
        )}

        {tab === 'refeicoes' && (
          <Card>
            <h3>Refeições</h3>
            {!canMeals ? <div>Seu perfil não pode gerenciar refeições.</div> : (
              <div style={{ display: 'grid', gap: 18 }}>
                {participants.map((p) => (
                  <Card key={p.id} style={{ padding: 16 }}>
                    <div style={{ display: 'grid', gap: 6, marginBottom: 12 }}>
                      <strong>{p.full_name}</strong>
                      <span style={{ color: '#64748b', fontSize: 14 }}>Restrições: {p.restrictions || 'Nenhuma'} • PCD: {p.pcd || 'Não informado'}</span>
                    </div>
                    <Table
                      columns={['Dia', ...MEAL_TYPES]}
                      rows={EVENT_DAYS}
                      renderRow={(day) => (
                        <tr key={day}>
                          <td style={td}>{day}</td>
                          {MEAL_TYPES.map((meal) => (
                            <td style={td} key={meal}>
                              <label style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                                <input
                                  type="checkbox"
                                  checked={isDispensed(p.id, day, meal)}
                                  onChange={() => toggleMeal(p.id, day, meal)}
                                />
                                Dispensar
                              </label>
                            </td>
                          ))}
                        </tr>
                      )}
                    />
                  </Card>
                ))}
              </div>
            )}
          </Card>
        )}

        {tab === 'auditoria' && (
          <Card>
            <h3>Auditoria</h3>
            {!canAudit ? <div>Somente admin pode visualizar auditoria.</div> : (
              <Table
                columns={['Data/Hora', 'Ação', 'Ator', 'Detalhes']}
                rows={audit}
                renderRow={(a) => (
                  <tr key={a.id}>
                    <td style={td}>{new Date(a.at).toLocaleString('pt-BR')}</td>
                    <td style={td}>{a.action}</td>
                    <td style={td}>{a.actor}</td>
                    <td style={td}><code>{a.payload}</code></td>
                  </tr>
                )}
              />
            )}
          </Card>
        )}
      </Container>
    </Page>
  )
}

function Metric({ icon, label, value }) {
  return (
    <Card>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ display: 'grid', gap: 6 }}>
          <span style={{ color: '#64748b' }}>{label}</span>
          <strong style={{ fontSize: 26 }}>{value}</strong>
        </div>
        <div style={{ border: '1px solid #cbd5e1', padding: 12, borderRadius: 16 }}>{icon}</div>
      </div>
    </Card>
  )
}

function Line({ label, value }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '12px 0', borderBottom: '1px solid #e2e8f0' }}>
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  )
}

function MoveSelector({ reservation, units, onMove }) {
  const [value, setValue] = useState('')
  return (
    <div style={{ display: 'flex', gap: 8 }}>
      <select value={value} onChange={(e) => setValue(e.target.value)} style={{ padding: 10, borderRadius: 10, border: '1px solid #cbd5e1' }}>
        <option value="">Mover para...</option>
        {units.map((u) => <option key={u.id} value={u.id}>{u.label} • {u.occupants.length}/{u.capacity}</option>)}
      </select>
      <Button variant="secondary" onClick={() => value && onMove(reservation.id, value)}>Mover</Button>
    </div>
  )
}

const td = { padding: 12, borderBottom: '1px solid #e2e8f0', verticalAlign: 'top' }
