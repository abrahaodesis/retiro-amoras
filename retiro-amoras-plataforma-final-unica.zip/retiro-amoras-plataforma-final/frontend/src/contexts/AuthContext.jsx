import React, { createContext, useContext, useEffect, useMemo, useState } from 'react'
import { api } from '../lib/api'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [token, setToken] = useState(() => localStorage.getItem('retiro_amoras_token') || '')
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(false)

  const login = async (email, password) => {
    setLoading(true)
    try {
      const { data } = await api.post('/auth/login', { email, password })
      localStorage.setItem('retiro_amoras_token', data.access_token)
      setToken(data.access_token)
      const me = await api.get('/auth/me', {
        headers: { Authorization: `Bearer ${data.access_token}` }
      })
      setUser(me.data)
      return { ok: true }
    } catch (error) {
      const message = error?.response?.data?.detail || 'Falha no login'
      return { ok: false, message }
    } finally {
      setLoading(false)
    }
  }

  const logout = () => {
    localStorage.removeItem('retiro_amoras_token')
    setToken('')
    setUser(null)
  }

  const loadMe = async () => {
    if (!token) return
    setLoading(true)
    try {
      const { data } = await api.get('/auth/me')
      setUser(data)
    } catch {
      logout()
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadMe()
  }, [token])

  const value = useMemo(() => ({
    token,
    user,
    loading,
    isAuthenticated: !!token && !!user,
    login,
    logout
  }), [token, user, loading])

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  return useContext(AuthContext)
}
