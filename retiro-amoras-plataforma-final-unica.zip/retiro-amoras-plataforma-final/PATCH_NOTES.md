# Patch notes — billing

## Adicionado
- plans
- subscriptions
- billing_payments
- bloqueio por assinatura ativa
- limites por plano

## Próximo passo
Integrar gateway real:
- Stripe
- Mercado Pago
- Asaas
- Pagar.me
