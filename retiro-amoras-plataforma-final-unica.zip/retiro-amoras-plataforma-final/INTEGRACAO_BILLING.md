# Como integrar o módulo de billing

## 1. Pré-requisito
Aplique antes o patch multi-tenant.

## 2. Copie
- `app/models/billing.py`
- `app/schemas/billing.py`
- `app/services/billing_service.py`
- `app/api/v1/endpoints/billing.py`

## 3. Registre as rotas no `api.py`
Exemplo:
```python
from app.api.v1.endpoints import billing
api_router.include_router(billing.router, prefix="/billing", tags=["billing"])
```

## 4. Permissões
Mescle o patch de permissions.

## 5. Antes de criar participantes/reservas
Use:
- `ensure_plan_limit_for_participants`
- `ensure_plan_limit_for_reservations`

## 6. Rodar migration
Aplicar `0003_billing_module.py`
